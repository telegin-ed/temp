@test "test" {
  echo output
}
