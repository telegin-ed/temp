@test test { :; }
