# start point
# https://github.com/omerxx/dotfiles/blob/master/tmux/README.md

# fonts
# JetBrainsMonoNLNerdFon and set for using in terminal

# install tpm from git into folder ~/.config/tmux as show bellow
# after restart tpm press bind + I to install other plugins from tmux.config

---

# ~/.config/tmux/tmux.conf

## Install
Once everything has been installed it's time to run TPM, install first:
```bash
git clone https://github.com/tmux-plugins/tpm ~/.config/tmux/plugins/tpm
```

## Run
`Ctrl+I`
